-- ============================================================================
-- ADARSH MOTORS - SUPABASE DATABASE SCHEMA (CLEAN SETUP WITH CASCADE DROP)
-- Fixes: ERROR 42703: column "phone" does not exist
-- 
-- Instructions:
-- 1. Open your Supabase Dashboard: https://supabase.com/dashboard
-- 2. Open SQL Editor (Left sidebar icon >_)
-- 3. Click "New Query", paste this entire script, and click "RUN" (Ctrl+Enter)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- STEP 1: DROP OLD / PARTIAL TABLES (Ensures all columns exist cleanly)
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS public.invoices CASCADE;
DROP TABLE IF EXISTS public.leads CASCADE;
DROP TABLE IF EXISTS public.site_settings CASCADE;
DROP TABLE IF EXISTS public.branches CASCADE;
DROP TABLE IF EXISTS public.bikes CASCADE;

-- ----------------------------------------------------------------------------
-- STEP 2: CREATE FRESH TABLES WITH ALL REQUIRED COLUMNS
-- ----------------------------------------------------------------------------

-- 1. TABLE: bikes (Live Showroom Inventory)
CREATE TABLE public.bikes (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  brand TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Superbikes',
  year INTEGER NOT NULL,
  km TEXT NOT NULL,
  engine TEXT NOT NULL,
  hp TEXT NOT NULL,
  price_raw NUMERIC NOT NULL,
  price TEXT NOT NULL,
  location TEXT NOT NULL,
  image_url TEXT NOT NULL,
  badge TEXT NOT NULL DEFAULT 'PRE-OWNED',
  fuel TEXT NOT NULL DEFAULT 'Petrol',
  acceleration TEXT NOT NULL DEFAULT '3.0s',
  tagline TEXT,
  addon_name TEXT,
  addon_price TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. TABLE: branches (Showroom & Lounge Locations)
CREATE TABLE public.branches (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  city TEXT NOT NULL,
  address TEXT NOT NULL,
  timings TEXT NOT NULL,
  maps_query TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. TABLE: site_settings (Hero Banner Slides, Contact Phone, Social Links)
CREATE TABLE public.site_settings (
  id BIGSERIAL PRIMARY KEY,
  key TEXT UNIQUE NOT NULL DEFAULT 'general',
  phone TEXT DEFAULT '+91 9014540489',
  instagram TEXT DEFAULT 'https://instagram.com/adarshmotors',
  hero_slides JSONB,
  updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. TABLE: leads (Customer Inquiries: Test Ride, Sell Valuation, Service, Loan)
CREATE TABLE public.leads (
  id BIGSERIAL PRIMARY KEY,
  type TEXT NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  bike_model TEXT,
  year TEXT,
  km TEXT,
  expected_price TEXT,
  condition TEXT,
  photos_count INTEGER DEFAULT 0,
  preferred_date TEXT,
  license_status TEXT,
  branch TEXT,
  service_type TEXT,
  loan_amount TEXT,
  tenure TEXT,
  employment_type TEXT,
  email TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. TABLE: invoices (My Garage Verification & Service Records with Phone + Email 2FA)
CREATE TABLE public.invoices (
  id TEXT PRIMARY KEY,
  phone TEXT NOT NULL,
  email TEXT NOT NULL DEFAULT 'kannapavan30@gmail.com',
  owner TEXT NOT NULL,
  vehicle TEXT NOT NULL,
  reg_no TEXT NOT NULL,
  vin TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  delivery_date TEXT NOT NULL,
  warranty TEXT NOT NULL,
  last_service TEXT,
  next_service TEXT,
  service_advisor TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX idx_invoices_phone ON public.invoices(phone);
CREATE INDEX idx_invoices_email ON public.invoices(email);
CREATE INDEX idx_invoices_phone_email ON public.invoices(phone, email);

-- ----------------------------------------------------------------------------
-- STEP 3: CONFIGURE ROW LEVEL SECURITY (RLS) POLICIES
-- Allows website visitors to view bikes and submit customer inquiries
-- ----------------------------------------------------------------------------
ALTER TABLE public.bikes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

-- Allow public read access to fleet, branches, settings, and invoices
CREATE POLICY "Public can view bikes" ON public.bikes FOR SELECT USING (true);
CREATE POLICY "Public can view branches" ON public.branches FOR SELECT USING (true);
CREATE POLICY "Public can view site settings" ON public.site_settings FOR SELECT USING (true);
CREATE POLICY "Public can lookup their invoice by phone" ON public.invoices FOR SELECT USING (true);

-- Allow public to submit customer inquiries
CREATE POLICY "Public can submit leads" ON public.leads FOR INSERT WITH CHECK (true);

-- ----------------------------------------------------------------------------
-- STEP 4: SEED INITIAL SHOWROOM FLEET, BRANCHES, SLIDES & GARAGE DATA
-- ----------------------------------------------------------------------------

-- Seed: BIKES
INSERT INTO public.bikes (id, name, brand, category, year, km, engine, hp, price_raw, price, location, image_url, badge, fuel, acceleration, tagline, addon_name, addon_price)
VALUES
('bike-1', 'KAWASAKI NINJA Z900', 'Kawasaki', 'Superbikes', 2024, '1,456 km', '948 cc Inline-4', '125 hp', 920000, '₹9,20,000', 'Hyderabad – Main Showroom', '/assets/aistudio/image_f4045ab9.png', 'PRE-OWNED', 'Petrol', '3.4s', 'Raw inline-4 symphony with Sugomi attitude.', 'KTM / Kawasaki Racing Jacket', '₹16,500'),
('bike-2', 'BMW S1000RR M-SPORT', 'BMW', 'Superbikes', 2024, '3,200 km', '999 cc ShiftCam', '205 hp', 2350000, '₹23,50,000', 'Hyderabad – Banjara Hills', '/assets/aistudio/image_f406ab38.png', 'PRE-OWNED', 'Petrol', '2.9s', 'Track weapon with aerodynamic carbon winglets.', 'BMW M Carbon Helmet', '₹42,000'),
('bike-3', 'DUCATI DIAVEL V4', 'Ducati', 'Superbikes', 2024, '1,112 km', 'V4 1158 cc Granturismo', '168 hp', 2890000, '₹28,90,000', 'Hyderabad – Main Showroom', '/assets/aistudio/image_f406ab38.png', 'PRE-OWNED', 'Petrol', '3.1s', 'Muscular stance with superbike heart.', 'Ducati Corse Riding Leather', '₹38,500'),
('bike-4', 'KTM 1290 SUPER DUKE R', 'KTM', 'Superbikes', 2023, '1,845 km', '1301 cc LC8 V-Twin', '180 hp', 1850000, '₹18,50,000', 'Bengaluru Branch', '/assets/aistudio/image_5a6010cd.png', 'PRE-OWNED', 'Petrol', '3.1s', 'The Beast. The ultimate hyper-naked machine.', 'KTM PowerWear Jacket', '₹18,500'),
('bike-5', 'HONDA ACTIVA 6G PREMIUM', 'Honda', 'Scooters', 2023, '5,000 km', '110 cc eSP HET', '7.8 hp', 85000, '₹85,000', 'Hyderabad – Main Showroom', '/assets/aistudio/image_f4045ab9.png', 'PRE-OWNED', 'Petrol', '7.2s', 'India''s highest reliability daily commuter.', 'Studds Urban Shield Helmet', '₹2,200'),
('bike-6', 'KAWASAKI NINJA ZX-10R', 'Kawasaki', 'Superbikes', 2023, '4,100 km', '998 cc WSBK Spec', '203 hp', 1680000, '₹16,80,000', 'Mumbai Branch', '/assets/aistudio/image_f4045ab9.png', 'PRE-OWNED', 'Petrol', '2.8s', 'Multiple World Superbike Championship winner.', 'Akrapovic Full Titanium Decat', '₹85,000'),
('bike-7', 'ROYAL ENFIELD CONTINENTAL GT 650', 'Royal Enfield', 'Mid-Range', 2023, '6,200 km', '648 cc Parallel Twin', '47 hp', 345000, '₹3,45,000', 'Hyderabad – Banjara Hills', '/assets/aistudio/image_f4045ab9.png', 'PRE-OWNED', 'Petrol', '5.8s', 'Authentic cafe racer with clip-on handlebars.', 'Royal Enfield Leather Gloves', '₹4,500'),
('bike-8', 'DAINESE MISANO 2 D-AIR RACE SUIT', 'Dainese', 'Accessories', 2024, 'Brand New', 'Airbag Tech', 'Level 2 Armor', 145000, '₹1,45,000', 'Hyderabad & Pan-India Dispatch', '/assets/aistudio/image_5a6010cd.png', 'NEW', 'N/A', '0.04s deploy', 'MotoGP certified wireless intelligent airbag suit.', 'AGV Pista GP RR Carbon Helmet', '₹95,000');

-- Seed: BRANCHES
INSERT INTO public.branches (id, name, city, address, timings, maps_query)
VALUES
('hyd-main', 'Hyderabad – Main Superbike Showroom', 'Hyderabad', 'Plot 48, Road No. 36, Jubilee Hills, Hyderabad, Telangana 500033', 'Mon – Sun: 10:00 AM – 8:30 PM (Air-conditioned valet lounge)', 'Adarsh+Motors+Jubilee+Hills+Hyderabad'),
('hyd-banjara', 'Hyderabad – Banjara Hills Superbike Lounge', 'Hyderabad', 'Road No. 12, MLA Colony, Banjara Hills, Hyderabad, Telangana 500034', 'Mon – Sun: 10:30 AM – 8:00 PM', 'Adarsh+Motors+Banjara+Hills+Hyderabad'),
('blr-hub', 'Bengaluru – Indiranagar Experience Centre', 'Bengaluru', '100 Feet Road, HAL 2nd Stage, Indiranagar, Bengaluru, Karnataka 560038', 'Mon – Sun: 10:00 AM – 9:00 PM', 'Adarsh+Motors+Indiranagar+Bengaluru'),
('mum-west', 'Mumbai – Andheri West Showroom', 'Mumbai', 'New Link Road, Next to Lotus Petrol Pump, Andheri West, Mumbai, MH 400053', 'Mon – Sun: 10:00 AM – 8:30 PM', 'Adarsh+Motors+Andheri+West+Mumbai');

-- Seed: SITE SETTINGS (Including Hero Banner Carousel Slides)
INSERT INTO public.site_settings (key, phone, instagram, hero_slides)
VALUES
(
  'general',
  '+91 9014540489',
  'https://instagram.com/adarshmotors',
  '[
    {
      "id": "buy",
      "badge": "Certified Fleet · Live Inventory",
      "badgeIcon": "fa-solid fa-motorcycle text-red-500",
      "title": "Buy Your <span class=\"text-red-500 drop-shadow-[0_0_20px_rgba(220,38,38,0.7)]\">Dream Bike.</span>",
      "description": "Handpicked, 150-point inspected premium superbikes. Guaranteed clean title, ready for instant physical inspection & delivery.",
      "image": "/assets/aistudio/image_f4045ab9.png",
      "ctaText": "Explore Inventory",
      "ctaAction": "inventory",
      "ctaIcon": "fa-solid fa-motorcycle",
      "ctaBtnClass": "bg-red-600 hover:bg-red-700 shadow-glow-red text-white",
      "secondaryText": "WhatsApp Desk",
      "secondaryAction": "whatsapp:Hello Adarsh Motors, I would like to enquire about purchasing a superbike.",
      "highlights": [
        {"icon": "fa-solid fa-shield-check text-red-500", "text": "150-Point Inspection"},
        {"icon": "fa-solid fa-file-shield text-emerald-400", "text": "Verified RC Transfer"},
        {"icon": "fa-solid fa-truck-fast text-amber-400", "text": "Pan-India Dispatch"}
      ]
    },
    {
      "id": "sell",
      "badge": "Fastest Two-Wheeler Valuation",
      "badgeIcon": "fa-solid fa-bolt text-emerald-400",
      "title": "Sell Your Bike <span class=\"text-emerald-400 drop-shadow-[0_0_20px_rgba(16,185,129,0.7)]\">in 15 Mins.</span>",
      "description": "Best market price guaranteed. Submit your vehicle photos for quick valuation, instant bank transfer, and zero brokerage.",
      "image": "/assets/aistudio/image_5a6010cd.png",
      "ctaText": "Get Instant Valuation",
      "ctaAction": "sell",
      "ctaIcon": "fa-solid fa-hand-holding-dollar",
      "ctaBtnClass": "bg-emerald-600 hover:bg-emerald-700 shadow-[0_0_25px_rgba(16,185,129,0.4)] text-white",
      "secondaryText": "Chat Valuation",
      "secondaryAction": "whatsapp:Hello Adarsh Motors, I want to sell my bike. Please guide me on valuation.",
      "highlights": [
        {"icon": "fa-solid fa-money-bill-transfer text-emerald-400", "text": "Instant Spot Payment"},
        {"icon": "fa-solid fa-house-chimney text-amber-400", "text": "Free Doorstep Inspection"},
        {"icon": "fa-solid fa-ban text-red-400", "text": "Zero Commission"}
      ]
    },
    {
      "id": "service",
      "badge": "Factory-Trained Superbike Care",
      "badgeIcon": "fa-solid fa-screwdriver-wrench text-amber-500",
      "title": "Get Your Superbike <span class=\"text-amber-400 drop-shadow-[0_0_20px_rgba(245,158,11,0.7)]\">Serviced.</span>",
      "description": "Specialized ECU diagnostics, suspension tuning, genuine OEM spares, and track-ready dyno service by certified master techs.",
      "image": "/assets/aistudio/image_f406ab38.png",
      "ctaText": "Book Service Slot",
      "ctaAction": "service",
      "ctaIcon": "fa-solid fa-calendar-check",
      "ctaBtnClass": "bg-amber-500 hover:bg-amber-600 shadow-[0_0_25px_rgba(245,158,11,0.4)] text-black font-black",
      "secondaryText": "Service Menu",
      "secondaryAction": "service-section",
      "highlights": [
        {"icon": "fa-solid fa-microchip text-amber-400", "text": "Live OBD Diagnostics"},
        {"icon": "fa-solid fa-gear text-red-400", "text": "100% Genuine OEM Spares"},
        {"icon": "fa-solid fa-stopwatch text-emerald-400", "text": "Same-Day Delivery Option"}
      ]
    },
    {
      "id": "loan",
      "badge": "Up to 90% Funding · Lowest Interest",
      "badgeIcon": "fa-solid fa-percent text-blue-400",
      "title": "Get Loan on <span class=\"text-blue-400 drop-shadow-[0_0_20px_rgba(37,99,235,0.7)]\">Your Vehicle.</span>",
      "description": "Turn your dream ride into reality with customized low-EMI superbike financing. Fast 2-hour spot approval with minimal documents.",
      "image": "/assets/aistudio/image_f4045ab9.png",
      "ctaText": "Apply for Vehicle Loan",
      "ctaAction": "loan",
      "ctaIcon": "fa-solid fa-credit-card",
      "ctaBtnClass": "bg-blue-600 hover:bg-blue-700 shadow-[0_0_25px_rgba(37,99,235,0.4)] text-white",
      "secondaryText": "WhatsApp Finance Desk",
      "secondaryAction": "whatsapp:Hello Adarsh Motors, I want to check my vehicle loan eligibility and interest rates.",
      "highlights": [
        {"icon": "fa-solid fa-clock text-blue-400", "text": "2-Hour In-Principle Sanction"},
        {"icon": "fa-solid fa-coins text-amber-400", "text": "Up to 90% On-Road Funding"},
        {"icon": "fa-solid fa-calendar text-emerald-400", "text": "Tenures up to 60 Months"}
      ]
    },
    {
      "id": "legacy",
      "badge": "South India''s Premier Superbike Destination",
      "badgeIcon": "fa-solid fa-award text-red-500",
      "title": "15+ Years <span class=\"text-red-500 drop-shadow-[0_0_20px_rgba(220,38,38,0.7)]\">Dealership Legacy.</span>",
      "description": "Over 2,500 machines delivered to passionate riders. Built on strict 150-point inspections, ironclad warranties, and zero hidden clauses.",
      "image": "/assets/aistudio/image_5a6010cd.png",
      "ctaText": "Discover Our Legacy",
      "ctaAction": "legacy",
      "ctaIcon": "fa-solid fa-shield-halved",
      "ctaBtnClass": "bg-red-600 hover:bg-red-700 shadow-glow-red text-white",
      "secondaryText": "Visit Showroom",
      "secondaryAction": "showroom",
      "highlights": [
        {"icon": "fa-solid fa-users text-red-500", "text": "2,500+ Happy Riders"},
        {"icon": "fa-solid fa-star text-amber-400", "text": "4.9★ Customer Rating"},
        {"icon": "fa-solid fa-certificate text-emerald-400", "text": "6-Month Powertrain Warranty"}
      ]
    }
  ]'::jsonb
);

-- Seed: INVOICES (My Garage Verification & Lookup with 2FA Phone + Email)
INSERT INTO public.invoices (id, phone, email, owner, vehicle, reg_no, vin, invoice_id, delivery_date, warranty, last_service, next_service, service_advisor)
VALUES
(
  'INV-2024-ADM-8492',
  '9014540489',
  'kannapavan30@gmail.com',
  'Kanna Pavan',
  'Kawasaki Ninja Z900 (Special Edition)',
  'TS 09 EG 7744',
  'JKAZR900PPA092144',
  'INV-2024-ADM-8492',
  '14 January 2024',
  'Active · 2-Year Engine & RSA Protection (Valid till Jan 2026)',
  'First 1,000 KM Inspection Completed on 22 Feb 2024',
  '6,000 KM Periodic Maintenance due in 1,200 KM',
  'Vikram Reddy (+91 9014540489)'
),
(
  'INV-2024-ADM-6102',
  '9876543210',
  'rajesh.kumar@gmail.com',
  'Rajesh Kumar',
  'Ducati Diavel V4 (Rosso Corsa)',
  'TS 10 AB 1234',
  'ZDM14BKW7PB018241',
  'INV-2024-ADM-6102',
  '05 March 2024',
  'Active · 24 Months Ducati Ever Red Warranty',
  'Pre-Delivery Inspection & Run-in check',
  'Annual Desmo Service at 15,000 KM',
  'Sandeep Rao (+91 9014540489)'
);
